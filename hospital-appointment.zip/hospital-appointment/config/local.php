<?php
return [
    'db_host' => '127.0.0.1',
    'db_port' => 3306,
    'db_name' => 'hospital-appointment',
    'db_user' => 'root',
    'db_pass' => '',
    'app_url' => 'http://localhost/hospital-appointment/public',
    'app_key' => '',
    'env' => 'production',

    'mail_enabled'    => true,
'mail_driver'     => 'smtp',
'mail_host'       => 'smtp.gmail.com',
'mail_port'       => 587,
'mail_encryption' => 'tls',
'mail_username'   => 'gary.misbah@gmail.com',
'mail_password'   => '',
'mail_from'       => 'gary.misbah@gmail.com',
'mail_from_name'  => 'Hospital Appointment System',
];
